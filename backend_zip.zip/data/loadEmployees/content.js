const fs = require('fs');
const csv = require('csv-parser');

async function beforeRender(req) {

    const employee = [];

    await new Promise((resolve, reject) => {

        fs.createReadStream('./employees.csv')
            .pipe(csv())
            .on('data', row => employee.push(row))
            .on('end', resolve)
            .on('error', reject);

    });

    req.data = {
        employee
    };
}